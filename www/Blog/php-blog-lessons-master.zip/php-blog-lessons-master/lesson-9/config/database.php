<?php

return [
    'dsn' => 'mysql:host=127.0.0.1;dbname=blog_php',
    'username' => 'root',
    'password' => '',
];
